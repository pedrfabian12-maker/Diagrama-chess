import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor config for Diagrama (Android APK).
 *
 * Two modes:
 * 1. **Remote (default / recommended to start)**  
 *    The APK loads your deployed web app (Vercel, etc.).  
 *    Set `server.url` to your production URL.
 *
 * 2. **Local static assets**  
 *    Comment out `server` and put a full static build in `www/`.  
 *    Use `npm run build:capacitor` then `npx cap sync`.
 *
 * After changing this file: `npx cap sync android`
 */
const config: CapacitorConfig = {
  appId: "app.diagrama.chess",
  appName: "Diagrama",
  webDir: "www",

  // Uncomment and set your production URL so the APK always loads the live app.
  // server: {
  //   url: "https://YOUR-APP.vercel.app",
  //   cleartext: false,
  // },

  android: {
    allowMixedContent: false,
    backgroundColor: "#234237",
  },

  plugins: {
    SplashScreen: {
      launchShowDuration: 0,
      backgroundColor: "#234237",
    },
  },
};

export default config;
