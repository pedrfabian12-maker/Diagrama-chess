package app.diagrama.chess;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
