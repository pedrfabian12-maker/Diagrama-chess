#!/usr/bin/env node
/**
 * Prepares `www/` for Capacitor.
 *
 * 1. Runs the normal Vite/Nitro production build.
 * 2. Copies client static assets into `www/`.
 * 3. Leaves a usable index.html (placeholder or updated shell).
 *
 * Note: this app is SSR (TanStack Start + Nitro). A pure offline SPA would
 * need a dedicated client entry. The recommended path for a working APK today
 * is to set `server.url` in capacitor.config.ts to your deployed URL, then
 * `npx cap sync android`. The local `www/` still satisfies Capacitor's webDir.
 */
import { cpSync, existsSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const ROOT = join(fileURLToPath(import.meta.url), "..", "..");
const WWW = join(ROOT, "www");
const STATIC = join(ROOT, ".vercel", "output", "static");

function run(cmd, args) {
  const r = spawnSync(cmd, args, { cwd: ROOT, stdio: "inherit", shell: false });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

console.log("[build:capacitor] Building web app…");
run("npm", ["run", "build"]);

if (!existsSync(STATIC)) {
  console.error("[build:capacitor] Missing .vercel/output/static — build failed?");
  process.exit(1);
}

console.log("[build:capacitor] Syncing static assets → www/");
mkdirSync(WWW, { recursive: true });

// Keep a minimal index if we don't overwrite with a real one.
const indexPath = join(WWW, "index.html");
const keepIndex = existsSync(indexPath);

// Copy public-like static files (assets, icons, etc.)
for (const name of ["assets", "__grok", "pdfjs", "favicon.svg", "og.jpg", "x-banner.jpg"]) {
  const src = join(STATIC, name);
  if (!existsSync(src)) continue;
  const dest = join(WWW, name);
  rmSync(dest, { recursive: true, force: true });
  cpSync(src, dest, { recursive: true });
}

if (!keepIndex) {
  writeFileSync(
    indexPath,
    `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <meta name="theme-color" content="#234237" />
  <title>Diagrama</title>
  <style>
    body { margin:0; min-height:100dvh; display:grid; place-items:center;
           background:#234237; color:#fcfcfc; font-family:system-ui,sans-serif; }
  </style>
</head>
<body>
  <p>Diagrama — configura server.url o usa el build remoto.</p>
</body>
</html>
`,
  );
}

console.log("[build:capacitor] Done. Next:");
console.log("  1. Edit capacitor.config.ts → set server.url to your deploy URL (recommended)");
console.log("  2. npx cap sync android");
console.log("  3. npx cap open android   (or open android/ in Android Studio)");
console.log("  4. Build → Generate Signed Bundle / APK");
