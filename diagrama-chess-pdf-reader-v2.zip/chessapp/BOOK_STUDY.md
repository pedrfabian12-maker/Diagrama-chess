# Lector de libros de ajedrez: primera integración

Se añadió `BookStudy` a la app Diagrama existente (React + Vite/TanStack + Capacitor + chess.js + pdfjs-dist).

## Funciones incluidas

- Acceso al lector desde el icono de libro de la pantalla principal.
- Abrir PDF local con el selector de archivos del dispositivo/navegador.
- Renderizar páginas y navegar anterior/siguiente.
- Extraer texto seleccionable de todas las páginas del PDF para buscar jugadas.
- Interpretar una línea principal de notación SAN en inglés o notación habitual en español (C/A/T/D/R) y validar cada jugada con chess.js.
- Tablero vinculado al índice de jugadas, controles anterior/siguiente y selección de jugadas.
- Modo de tablero libre con jugadas legales.
- Campo FEN para definir una posición inicial de un ejercicio.
- Mostrar aviso al primer movimiento que no pueda validarse, en vez de continuar con una posición incorrecta.

## Limitaciones deliberadas de esta primera versión

- La extracción de texto funciona con PDFs que contengan texto seleccionable. Los PDFs escaneados requieren OCR.
- La extracción actual detecta la línea principal; todavía no reconstruye con fiabilidad todas las variantes entre paréntesis, comentarios, diagramas e indicaciones de jugada.
- No se realiza reconocimiento visual automático de piezas de diagramas. Para hacerlo de forma fiable, hay que implementar recorte de página, OCR/visión, validación FEN y confirmación manual antes de incorporar la posición.
- No se puede garantizar cero errores con notación ambigua o extracción defectuosa. Se detiene ante la primera jugada ilegal.
- No se generó un APK en este entorno: las dependencias no pudieron instalarse dentro del tiempo disponible. Instalar y probar con `npm ci`, `npm run typecheck`, `npm run build:capacitor` y Android Studio antes de distribuir.

## Verificación local

```bash
npm ci
npm run typecheck
npm run build:capacitor
npx cap sync android
npx cap open android
```

Para un APK que abra en un dispositivo real, el proyecto debe usar un despliegue HTTPS compatible o configurarse para empaquetar los recursos como aplicación local. Revisar `ANDROID.md`.
