import type { Puzzle } from "@/lib/chess/types";

export const PUZZLES: Puzzle[] = [
  {
    id: "octava",
    title: "La octava libre",
    chapter: "Mate en uno",
    cite: "Esquema de mate en la última fila",
    brief: "Las blancas dan mate en una.",
    fen: "6k1/5ppp/8/8/8/8/8/4R2K w - - 0 1",
    solution: ["Re8#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La torre de e1 tiene la columna abierta y la octava despejada. El rey negro está encerrado por sus peones.",
      },
      {
        afterPly: 1,
        title: "Te8 mate",
        note: "La torre cubre f8 y h8. f7, g7 y h7 los tapa el propio negro. No hay captura ni interposición.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "dama-rey",
    title: "Dama y rey",
    chapter: "Mate en uno",
    cite: "Esquema de rey y dama",
    brief: "Las blancas dan mate en una.",
    fen: "6k1/4Q3/6K1/8/8/8/8/8 w - - 0 1",
    solution: ["Qg7#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La dama está en e7 y el rey blanco en g6, a un paso de sostener el mate en g7.",
      },
      {
        afterPly: 1,
        title: "Dg7 mate",
        note: "La dama da jaque al lado del rey y el rey blanco la defiende. f8, f7, h8 y h7 también quedan tomados.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "opera",
    title: "La ópera",
    chapter: "Mate en dos",
    cite: "Morphy — duque de Brunswick y conde Isouard, París, 1858",
    brief: "Las blancas dan mate en dos.",
    fen: "4kb1r/p2n1ppp/4q3/4p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 1 1",
    solution: ["Qb8+", "Nxb8", "Rd8#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La torre de d1 mira al rey de e8. El alfil de g5 cubre e7 y, cuando la torre entre, defenderá d8.",
      },
      {
        afterPly: 1,
        title: "Desvío",
        note: "Db8+ obliga al caballo de d7 a capturar la dama. Esa es la pieza que estorbaba el mate.",
      },
      {
        afterPly: 3,
        title: "Td8 mate",
        note: "La torre mata en d8, defendida por el alfil. El caballo de b8 y la dama de e6 le quitan casillas al rey.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "buckle",
    title: "Buckle",
    chapter: "Mate en dos",
    cite: "Buckle — NN, Londres, 1840",
    brief: "Las blancas dan mate en dos.",
    fen: "r2qkb1r/pp2nppp/3p4/2pNN1B1/2BnP3/3P4/PPP2PPP/R2bK2R w KQkq - 1 1",
    solution: ["Nf6+", "gxf6", "Bxf7#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "Dos caballos, en d5 y e5, y el alfil de c4 rodean f7. El alfil de g5 no deja respirar el enroque.",
      },
      {
        afterPly: 1,
        title: "Cf6+",
        note: "El caballo de d5 salta a f6 con jaque. La única respuesta legal es gxCf6.",
      },
      {
        afterPly: 3,
        title: "Axf7 mate",
        note: "El alfil de c4 toma en f7. El caballo de e5 defiende esa casilla y el rey de e8 no tiene salida.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "zukertort",
    title: "Zukertort",
    chapter: "Mate en dos",
    cite: "Zukertort — Anderssen, Breslau, 1865",
    brief: "Las blancas dan mate en dos.",
    fen: "r1b2k1r/ppp1bppp/8/1B1Q4/5q2/2P5/PPP2PPP/R3R1K1 w - - 1 1",
    solution: ["Qd8+", "Bxd8", "Re8#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La torre de e1 ya apunta a la octava. El alfil de e7 es el que puede tapar el mate.",
      },
      {
        afterPly: 1,
        title: "Dd8+",
        note: "La dama se sacrifica en d8 para que el alfil de e7 tenga que tomarla y deje la fila.",
      },
      {
        afterPly: 3,
        title: "Te8 mate",
        note: "La torre entra en e8. El alfil de b5 la defiende. El rey de f8 está en la última fila, sin aire.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "blackburne",
    title: "Blackburne",
    chapter: "Mate en dos",
    cite: "Blackburne — Martin, Inglaterra, 1876",
    brief: "Las blancas dan mate en dos.",
    fen: "1r1kr3/Nbppn1pp/1b6/8/6Q1/3B1P2/Pq3P1P/3RR1K1 w - - 1 1",
    solution: ["Qxd7+", "Kxd7", "Bb5#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La dama de g4 y el alfil de d3 miran hacia el rey de c8. d7 es el punto de contacto.",
      },
      {
        afterPly: 1,
        title: "Dxd7+",
        note: "La dama toma en d7 con jaque y el rey tiene que capturarla.",
      },
      {
        afterPly: 3,
        title: "Ab5 mate",
        note: "Con el rey ya en d7, el alfil de d3 llega a b5. El jaque es mate.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "neumann",
    title: "Neumann",
    chapter: "Mate en dos",
    cite: "Neumann — Mayet, Berlín, 1866",
    brief: "Las blancas dan mate en dos.",
    fen: "5rkr/pp2Rp2/1b1p1Pb1/3P2Q1/2n3P1/2p5/P4P2/4R1K1 w - - 1 1",
    solution: ["Qxg6+", "fxg6", "Rg7#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La torre blanca ya está en e7, dentro de la posición. La dama de g5 puede abrir g7.",
      },
      {
        afterPly: 1,
        title: "Dxg6+",
        note: "La dama toma el alfil de g6 con jaque. El peón de f7 tiene que capturar.",
      },
      {
        afterPly: 3,
        title: "Tg7 mate",
        note: "La torre pasa de e7 a g7. El peón de f6 defiende esa casilla y el rey de g8 no escapa.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "smith",
    title: "El caballo de e5",
    chapter: "Mate en dos",
    cite: "Blackburne — Smith, sesión simultánea, 1882",
    brief: "Las blancas dan mate en dos.",
    fen: "r1nk3r/2b2ppp/p3b3/3NN3/Q2P3q/B2B4/P4PPP/4R1K1 w - - 1 1",
    solution: ["Qd7+", "Bxd7", "Nxf7#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La dama de a4 tiene la diagonal hacia d7. El caballo de e5 espera el salto a f7.",
      },
      {
        afterPly: 1,
        title: "Dd7+",
        note: "La dama da jaque en d7 y el alfil de c7 es quien debe tomarla.",
      },
      {
        afterPly: 3,
        title: "Cxf7 mate",
        note: "El caballo de e5 entra en f7. No es la dama la que mata: es el caballo, con el rey de d8 sin salida.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "coronacion",
    title: "Coronación menor",
    chapter: "Patrones",
    cite: "Louis Paulsen — Blachy, Nueva York, 1857",
    brief: "Las blancas dan mate en dos. La coronación no es de dama.",
    fen: "1rb4r/pkPp3p/1b1P3n/1Q6/N3Pp2/8/P1P3PP/7K w - - 1 1",
    solution: ["Qd5+", "Ka6", "cxb8=N#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "Hay un peón blanco en c7, a un paso de la octava, y la dama en b5. El rey negro está en b7.",
      },
      {
        afterPly: 1,
        title: "Dd5+",
        note: "El jaque empuja al rey hacia a6. Ahora b8 queda libre para el peón.",
      },
      {
        afterPly: 3,
        title: "cxb8=C mate",
        note: "Si coronas dama, no es la línea. El caballo en b8 da el mate al rey de a6.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "ahogado",
    title: "Mate ahogado",
    chapter: "Patrones",
    cite: "Esquema de dama y caballo",
    brief: "Las blancas dan mate en dos.",
    fen: "5r1k/6pp/7N/8/8/8/Q7/6K1 w - - 0 1",
    solution: ["Qg8+", "Rxg8", "Nf7#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "El caballo de h6 defiende g8. La dama de a2 puede entrar ahí por la diagonal. El rey ya está en el rincón.",
      },
      {
        afterPly: 1,
        title: "Dg8+",
        note: "La dama se entrega en g8, protegida por el caballo. La única respuesta es Txg8.",
      },
      {
        afterPly: 3,
        title: "Cf7 mate",
        note: "El caballo salta a f7. g7, g8 y h7 los ocupan piezas negras. El rey no puede tomar el caballo ni salir.",
      },
    ],
    origin: "cuaderno",
  },
  {
    id: "paulsen-anderssen",
    title: "Sacrificio en f8",
    chapter: "Patrones",
    cite: "W. Paulsen — Anderssen, Fráncfort, 1878",
    brief: "Las blancas dan mate en dos.",
    fen: "5rk1/1p1q2bp/p2pN1p1/2pP2Bn/2P3P1/1P6/P4QKP/5R2 w - - 1 1",
    solution: ["Qxf8+", "Bxf8", "Rxf8#"],
    schemes: [
      {
        afterPly: 0,
        title: "Diagrama",
        note: "La dama de f2 y la torre de f1 están en la misma columna que la torre negra de f8.",
      },
      {
        afterPly: 1,
        title: "Dxf8+",
        note: "La dama toma la torre con jaque. El alfil de g7 tiene que recapturar.",
      },
      {
        afterPly: 3,
        title: "Txf8 mate",
        note: "La torre blanca recaptura en f8 y da mate al rey de g8.",
      },
    ],
    origin: "cuaderno",
  },
];

export const CHAPTERS = ["Mate en uno", "Mate en dos", "Patrones"] as const;
