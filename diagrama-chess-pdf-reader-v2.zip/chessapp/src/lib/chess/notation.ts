import type { Color } from "chess.js";

const PIECE: Record<string, string> = {
  N: "C",
  B: "A",
  R: "T",
  Q: "D",
  K: "R",
};

export function sanEs(san: string): string {
  return san
    .replace(/^[NBRQK]/, (ch) => PIECE[ch] ?? ch)
    .replace(/=([NBRQK])/, (_, ch: string) => `=${PIECE[ch] ?? ch}`);
}

export type ScoreRow = { num: number; white?: string; black?: string; blackFirst?: boolean };

export function scoreRows(start: Color, sans: string[]): ScoreRow[] {
  const es = sans.map(sanEs);
  const rows: ScoreRow[] = [];
  let i = 0;
  let num = 1;
  if (start === "b" && es.length) {
    rows.push({ num, black: es[0], blackFirst: true });
    i = 1;
    num = 2;
  }
  while (i < es.length) {
    rows.push({ num, white: es[i], black: es[i + 1] });
    i += 2;
    num += 1;
  }
  return rows;
}
