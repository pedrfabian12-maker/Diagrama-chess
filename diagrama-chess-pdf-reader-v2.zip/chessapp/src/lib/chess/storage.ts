import type { Puzzle } from "@/lib/chess/types";

const PUZZLES_KEY = "diagrama.puzzles.v1";
const PROGRESS_KEY = "diagrama.progress.v1";

export type Progress = Record<string, { solved: boolean; wrong: number }>;

function readJson<T>(key: string, fallback: T): T {
  if (typeof localStorage === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function loadPuzzles(): Puzzle[] {
  const list = readJson<Puzzle[]>(PUZZLES_KEY, []);
  return Array.isArray(list) ? list.filter((p) => p && p.origin === "tuyo" && p.fen && p.solution) : [];
}

export function savePuzzles(puzzles: Puzzle[]) {
  localStorage.setItem(PUZZLES_KEY, JSON.stringify(puzzles.slice(0, 40)));
}

export function loadProgress(): Progress {
  const data = readJson<Progress>(PROGRESS_KEY, {});
  return data && typeof data === "object" ? data : {};
}

export function saveProgress(progress: Progress) {
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));
}
