import { createServerFn } from "@tanstack/react-start";
import { coerceFen } from "@/lib/chess/position";

const PROMPT = `Transcribes a chess diagram into FEN. The image is a crop from a chess book.
White is at the bottom unless the diagram is clearly printed with Black at the bottom.
Ignore captions if the pieces are still visible. If arrows cover a piece, infer the piece only when the shape is clear.
Return JSON only, no markdown:
{"fen":"<full FEN or null>","warning":"<short Spanish note, or empty string>"}
Rules:
- Six FEN fields. If castling rights are unclear, use "-". Do not invent castling.
- En passant "-". Halfmove 0. Fullmove 1, unless a caption states the move number.
- Side to move is w unless the caption says Black to move, "juegan negras", or shows a black-to-move mark.
- Exactly one king of each color.
- If this is not a chessboard, set fen to null.`;

export const readDiagram = createServerFn({ method: "POST" })
  .validator((input: { image: string }) => {
    if (!input || typeof input.image !== "string" || !input.image.startsWith("data:image/")) {
      throw new Error("El recorte no es una imagen.");
    }
    if (input.image.length > 1_800_000) {
      throw new Error("El recorte es demasiado grande. Márcalo más cerca del tablero.");
    }
    return { image: input.image };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "La lectura automática no está disponible. Monta la posición a mano." };
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0,
        max_tokens: 400,
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: PROMPT },
              { type: "image_url", image_url: { url: data.image, detail: "high" } },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false as const, error: "No se pudo leer el diagrama. Monta la posición a mano." };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content ?? "";
    let parsed: { fen?: string | null; warning?: string } = {};
    try {
      const start = text.indexOf("{");
      const end = text.lastIndexOf("}");
      if (start < 0 || end < start) throw new Error("sin json");
      parsed = JSON.parse(text.slice(start, end + 1)) as { fen?: string | null; warning?: string };
    } catch {
      return { ok: false as const, error: "La lectura no devolvió una posición. Monta el diagrama a mano." };
    }

    if (!parsed.fen) {
      return {
        ok: false as const,
        error: parsed.warning || "No reconocí un tablero en ese recorte.",
      };
    }

    const fen = coerceFen(String(parsed.fen));
    if (!fen) {
      return {
        ok: false as const,
        error: "La posición leída no es legal. Revísala y colócala a mano.",
      };
    }

    return {
      ok: true as const,
      fen,
      warning: parsed.warning?.trim() || "Revisa pieza por pieza antes de guardar la línea.",
    };
  });
