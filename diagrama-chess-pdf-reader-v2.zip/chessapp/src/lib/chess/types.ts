export type Scheme = {
  afterPly: number;
  title: string;
  note: string;
};

export type Puzzle = {
  id: string;
  title: string;
  chapter: string;
  cite: string;
  brief: string;
  fen: string;
  solution: string[];
  schemes: Scheme[];
  origin: "cuaderno" | "tuyo";
};
