import { Chess, validateFen, type Color, type PieceSymbol, type Square } from "chess.js";

export type Piece = { type: PieceSymbol; color: Color };
export type SquareMap = Partial<Record<Square, Piece>>;
export type Castling = { K: boolean; Q: boolean; k: boolean; q: boolean };

export const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;
export const RANK_NUMS = ["1", "2", "3", "4", "5", "6", "7", "8"] as const;

export function emptyCastling(): Castling {
  return { K: false, Q: false, k: false, q: false };
}

export function isDark(square: Square): boolean {
  const file = square.charCodeAt(0) - 97;
  const rank = Number(square[1]);
  return (file + rank) % 2 === 1;
}

export function tryMove(
  chess: Chess,
  move: string | { from: Square; to: Square; promotion?: "q" | "r" | "b" | "n" },
) {
  try {
    return chess.move(move);
  } catch {
    return null;
  }
}

export function fenAt(fen: string, moves: string[], ply: number): string {
  const chess = new Chess(fen);
  for (let i = 0; i < ply; i++) {
    if (!tryMove(chess, moves[i])) throw new Error("Línea inválida");
  }
  return chess.fen();
}

export function bookMove(fen: string, moves: string[], ply: number) {
  const chess = new Chess(fen);
  for (let i = 0; i < ply; i++) tryMove(chess, moves[i]);
  return ply < moves.length ? tryMove(chess, moves[ply]) : null;
}

function friendly(error: string): string {
  const e = error.toLowerCase();
  if (e.includes("missing white king")) return "Falta el rey blanco.";
  if (e.includes("missing black king")) return "Falta el rey negro.";
  if (e.includes("too many white kings")) return "Hay más de un rey blanco.";
  if (e.includes("too many black kings")) return "Hay más de un rey negro.";
  if (e.includes("pawns")) return "Un peón no puede quedarse en la primera ni en la última fila.";
  return "La posición no es legal.";
}

function kingsTouch(map: SquareMap): boolean {
  const kings: Square[] = [];
  for (const file of FILES) {
    for (const rank of RANK_NUMS) {
      const sq = `${file}${rank}` as Square;
      const piece = map[sq];
      if (piece?.type === "k") kings.push(sq);
    }
  }
  if (kings.length < 2) return false;
  for (let i = 0; i < kings.length; i++) {
    for (let j = i + 1; j < kings.length; j++) {
      const a = kings[i];
      const b = kings[j];
      const df = Math.abs(a.charCodeAt(0) - b.charCodeAt(0));
      const dr = Math.abs(Number(a[1]) - Number(b[1]));
      if (df <= 1 && dr <= 1) return true;
    }
  }
  return false;
}

export function mapToFen(
  map: SquareMap,
  turn: Color,
  castling: Castling,
): { fen: string | null; error: string | null } {
  if (kingsTouch(map)) return { fen: null, error: "Los reyes no pueden tocarse." };
  const ranks = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;
  let placement = "";
  for (const rank of ranks) {
    let empty = 0;
    for (const file of FILES) {
      const piece = map[`${file}${rank}` as Square];
      if (!piece) {
        empty += 1;
        continue;
      }
      if (empty) {
        placement += String(empty);
        empty = 0;
      }
      const letter = piece.type.toUpperCase();
      placement += piece.color === "w" ? letter : letter.toLowerCase();
    }
    if (empty) placement += String(empty);
    if (rank !== "1") placement += "/";
  }
  const castle =
    `${castling.K ? "K" : ""}${castling.Q ? "Q" : ""}${castling.k ? "k" : ""}${castling.q ? "q" : ""}` ||
    "-";
  const fen = `${placement} ${turn} ${castle} - 0 1`;
  const valid = validateFen(fen);
  if (!valid.ok) return { fen: null, error: friendly(valid.error) };
  try {
    return { fen: new Chess(fen).fen(), error: null };
  } catch {
    return { fen: null, error: "La posición no es legal." };
  }
}

export function fenToSetup(fen: string): { map: SquareMap; turn: Color; castling: Castling } | null {
  const valid = validateFen(fen);
  if (!valid.ok) return null;
  try {
    const chess = new Chess(fen);
    const map: SquareMap = {};
    for (const row of chess.board()) {
      for (const cell of row) {
        if (cell) map[cell.square] = { type: cell.type, color: cell.color };
      }
    }
    const castle = chess.fen().split(" ")[2] ?? "-";
    return {
      map,
      turn: chess.turn(),
      castling: {
        K: castle.includes("K"),
        Q: castle.includes("Q"),
        k: castle.includes("k"),
        q: castle.includes("q"),
      },
    };
  } catch {
    return null;
  }
}

export function rotate180(map: SquareMap): SquareMap {
  const next: SquareMap = {};
  for (const file of FILES) {
    for (const rank of RANK_NUMS) {
      const sq = `${file}${rank}` as Square;
      const piece = map[sq];
      if (!piece) continue;
      const nf = FILES[7 - FILES.indexOf(file)];
      const nr = String(9 - Number(rank));
      next[`${nf}${nr}` as Square] = piece;
    }
  }
  return next;
}

export function swapColors(map: SquareMap): SquareMap {
  const next: SquareMap = {};
  for (const [sq, piece] of Object.entries(map) as [Square, Piece][]) {
    next[sq] = { type: piece.type, color: piece.color === "w" ? "b" : "w" };
  }
  return next;
}

export function coerceFen(raw: string): string | null {
  const cleaned = raw
    .trim()
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  const match = cleaned.match(
    /([pnbrqkPNBRQK1-8]+\/[pnbrqkPNBRQK1-8/]+)\s*([wb])?(?:\s*([KQkq-]+))?(?:\s*([a-h][36]|-))?(?:\s*(\d+))?(?:\s*(\d+))?/,
  );
  if (!match) return null;
  const placement = match[1];
  const turn = match[2] || "w";
  const castle = match[3] || "-";
  const ep = match[4] || "-";
  const half = match[5] || "0";
  const full = match[6] || "1";
  const fen = `${placement} ${turn} ${castle} ${ep} ${half} ${full}`;
  if (!validateFen(fen).ok) return null;
  try {
    return new Chess(fen).fen();
  } catch {
    return null;
  }
}
