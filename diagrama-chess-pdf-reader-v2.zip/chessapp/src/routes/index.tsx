import { createFileRoute } from "@tanstack/react-router";
import { Diagrama } from "@/components/diagrama/Diagrama";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Diagrama />;
}
