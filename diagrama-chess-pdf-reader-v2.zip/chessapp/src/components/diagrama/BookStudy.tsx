import { useEffect, useMemo, useRef, useState } from "react";
import { Chess, type Square } from "chess.js";
import { BookOpen, ChevronLeft, ChevronRight, FileUp, RotateCcw, ScanText } from "lucide-react";
import { getDocument, GlobalWorkerOptions } from "pdfjs-dist";
import { Board } from "@/components/chess/Board";
import { sanEs } from "@/lib/chess/notation";

GlobalWorkerOptions.workerSrc = new URL("pdfjs-dist/build/pdf.worker.min.mjs", import.meta.url).toString();

type Ply = { san: string; fen: string; from: Square; to: Square };
const START_FEN = new Chess().fen();
const TOKEN_RE = /(?:\d+\.(?:\.\.)?|\.\.\.)|(?:O-O-O|O-O|0-0-0|0-0)|(?:[KQRBNACDT]?[a-h]?[1-8]?x?[a-h][1-8](?:=[QRBNACDT])?[+#]?)|(?:1-0|0-1|1\/2-1\/2|\*)/g;

function parseMoves(text: string, startFen = START_FEN): { moves: Ply[]; errors: string[] } {
  const normalized = text
    .replace(/[\u00a0\u2000-\u200b]/g, " ")
    .replace(/\{[^}]*\}/g, " ")
    .replace(/;[^\n]*/g, " ")
    .replace(/\([^)]*\)/g, " ")
    .replace(/\$\d+/g, " ");
  const tokens = normalized.match(TOKEN_RE) ?? [];
  const chess = new Chess(startFen);
  const moves: Ply[] = [];
  const errors: string[] = [];
  for (const raw of tokens) {
    if (/^(?:\d+\.(?:\.\.)?|\.\.\.|1-0|0-1|1\/2-1\/2|\*)$/.test(raw)) continue;
    const san = raw.replace(/[+#?!]+$/g, "").replace(/^0-0-0$/, "O-O-O").replace(/^0-0$/, "O-O");
    try {
      const move = chess.move(san.replace(/[ACDT]/g, (p) => ({ A: "B", C: "N", D: "Q", T: "R" })[p] ?? p));
      moves.push({ san: move.san, fen: chess.fen(), from: move.from, to: move.to });
    } catch {
      errors.push(`No se pudo validar «${raw}» después de ${moves.length} jugadas. Comprueba la notación, el idioma o la posición inicial.`);
      break;
    }
  }
  return { moves, errors };
}

export function BookStudy() {
  const [fileName, setFileName] = useState("");
  const [pageCount, setPageCount] = useState(0);
  const [page, setPage] = useState(1);
  const [pageText, setPageText] = useState("");
  const [status, setStatus] = useState("Abre un libro PDF para comenzar.");
  const [ply, setPly] = useState(0);
  const [fenInput, setFenInput] = useState(START_FEN);
  const [freePlay, setFreePlay] = useState(false);
  const [selected, setSelected] = useState<Square | null>(null);
  const [freeFen, setFreeFen] = useState(START_FEN);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pdfRef = useRef<any>(null);
  const safeStartFen = useMemo(() => { try { return new Chess(fenInput).fen(); } catch { return START_FEN; } }, [fenInput]);
  // Analiza solo la página visible: concatenar las 240 páginas mezcla partidas y posiciones distintas.
  const moves = useMemo(() => parseMoves(pageText, safeStartFen), [pageText, safeStartFen]);
  const currentFen = freePlay ? freeFen : ply === 0 ? safeStartFen : moves.moves[Math.min(ply, moves.moves.length) - 1]?.fen ?? safeStartFen;
  const currentChess = useMemo(() => new Chess(currentFen), [currentFen]);
  const legalTargets = selected ? currentChess.moves({ square: selected, verbose: true }).map((m) => ({ square: m.to, capture: Boolean(m.captured) })) : [];

  async function showPage(doc: any, number: number) {
    const pdfPage = await doc.getPage(number);
    const viewport = pdfPage.getViewport({ scale: 1.25 });
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      if (ctx) await pdfPage.render({ canvasContext: ctx, viewport }).promise;
    }
    const content = await pdfPage.getTextContent();
    const text = content.items.map((item: any) => typeof item.str === "string" ? item.str : "").join(" ");
    setPageText(text);
    setPage(number);
  }

  async function openPdf(file?: File) {
    if (!file) return;
    if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
      setStatus("Selecciona un archivo PDF."); return;
    }
    try {
      setStatus("Leyendo el PDF…");
      const bytes = await file.arrayBuffer();
      const doc = await getDocument({ data: bytes }).promise;
      pdfRef.current = doc;
      setFileName(file.name);
      setPageCount(doc.numPages);
      setPly(0); setFreePlay(false); setFreeFen(START_FEN); setFenInput(START_FEN);
      await showPage(doc, 1);
      setStatus(`PDF cargado: ${doc.numPages} páginas. Se analiza únicamente la página visible para no mezclar partidas de páginas diferentes.`);
    } catch (error) {
      setStatus(`No se pudo abrir el PDF: ${error instanceof Error ? error.message : "archivo inválido"}`);
    }
  }

  useEffect(() => { if (pdfRef.current) void showPage(pdfRef.current, page); }, [page]);

  function clickSquare(square: Square) {
    if (!freePlay) return;
    if (selected) {
      const test = new Chess(freeFen);
      try { test.move({ from: selected, to: square, promotion: "q" }); setFreeFen(test.fen()); setSelected(null); return; } catch { /* select another piece below */ }
    }
    const piece = currentChess.get(square);
    setSelected(piece?.color === currentChess.turn() ? square : null);
  }

  const moveList = moves.moves;
  return <div className="mx-auto max-w-6xl space-y-4 p-3 sm:p-5">
    <header className="flex flex-wrap items-center justify-between gap-3">
      <div><p className="text-xs uppercase tracking-[.18em] text-muted">Biblioteca de estudio</p><h1 className="font-display text-2xl sm:text-3xl">Libro + tablero</h1></div>
      <label className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-forest px-4 py-3 text-sm text-cream"><FileUp size={17}/> Abrir PDF<input className="hidden" type="file" accept="application/pdf,.pdf" onChange={(e) => void openPdf(e.target.files?.[0])}/></label>
    </header>
    <p className="rounded-xl border border-black/10 bg-white/70 p-3 text-sm text-muted">{status}</p>
    <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1.05fr)_minmax(320px,.95fr)]">
      <section className="min-w-0 space-y-3 rounded-2xl border border-black/10 bg-white/60 p-3 sm:p-4">
        <div className="flex items-center justify-between gap-2"><div className="flex min-w-0 items-center gap-2"><BookOpen size={18}/><span className="truncate text-sm font-medium">{fileName || "Vista del libro"}</span></div><span className="text-xs text-muted">{pageCount ? `${page}/${pageCount}` : "PDF"}</span></div>
        <div className="flex min-h-56 items-center justify-center overflow-auto rounded-lg bg-stone-200 p-2"><canvas ref={canvasRef} className="max-h-[72vh] max-w-full object-contain shadow-md" /></div>
        <div className="flex items-center justify-between"><button className="inline-flex items-center gap-1 rounded-lg border px-3 py-2 text-sm disabled:opacity-40" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))}><ChevronLeft size={16}/> Anterior</button><span className="text-xs text-muted">Página {pageCount ? page : 0} de {pageCount}</span><button className="inline-flex items-center gap-1 rounded-lg border px-3 py-2 text-sm disabled:opacity-40" disabled={page >= pageCount} onClick={() => setPage((p) => Math.min(pageCount, p + 1))}>Siguiente <ChevronRight size={16}/></button></div>
        <details className="rounded-lg border border-black/10 p-3"><summary className="cursor-pointer text-sm font-medium"><ScanText className="mr-2 inline size-4"/>Texto extraído de esta página</summary><p className="mt-2 whitespace-pre-wrap text-sm text-muted">{pageText || "No se detectó texto seleccionable en esta página."}</p></details>
      </section>
      <section className="min-w-0 space-y-3">
        <div className="rounded-2xl border border-black/10 bg-white/60 p-3 sm:p-4">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="font-display text-xl">Tablero de análisis</h2><button className="rounded-lg border px-3 py-2 text-xs" onClick={() => {setFreePlay((v) => !v); setSelected(null); setFreeFen(currentFen);}}>{freePlay ? "Volver a la línea" : "Mover libremente"}</button></div>
          <Board fen={currentFen} interactive={freePlay} selected={selected} targets={legalTargets} onSquare={clickSquare} />
          {freePlay ? <p className="mt-2 text-xs text-muted">Modo libre: puedes probar jugadas legales. La línea extraída no se modifica.</p> : <>
            <div className="mt-3 flex items-center justify-between gap-2"><button className="rounded-lg border p-2 disabled:opacity-40" aria-label="Reiniciar" disabled={!ply} onClick={() => setPly(0)}><RotateCcw size={17}/></button><span className="text-sm text-muted">{ply} / {moveList.length} medias jugadas</span><div className="flex gap-2"><button className="rounded-lg border p-2 disabled:opacity-40" aria-label="Jugada anterior" disabled={ply === 0} onClick={() => setPly((n) => Math.max(0, n - 1))}><ChevronLeft size={17}/></button><button className="rounded-lg border p-2 disabled:opacity-40" aria-label="Jugada siguiente" disabled={ply >= moveList.length} onClick={() => setPly((n) => Math.min(moveList.length, n + 1))}><ChevronRight size={17}/></button></div></div>
            <div className="mt-3 flex flex-wrap gap-1">{moveList.map((m, i) => <button key={`${i}-${m.san}`} className={`rounded-md px-2 py-1 text-sm ${ply === i + 1 ? "bg-forest text-cream" : "bg-black/5"}`} onClick={() => setPly(i + 1)} title={`Ir a la jugada ${i + 1}`}>{i % 2 === 0 ? `${Math.floor(i / 2) + 1}.${i % 2 === 0 ? "" : ".."}` : ""}{sanEs(m.san)}</button>)}</div>
          </>}
        </div>
        <div className="rounded-2xl border border-black/10 bg-white/60 p-3 sm:p-4"><h3 className="font-display text-lg">Interpretación y validación</h3><p className="mt-1 text-sm text-muted">Se reconocen jugadas legales de la página visible desde la posición inicial o desde una FEN introducida por ti. Las variantes entre paréntesis se omiten por ahora para no mezclarlas con la línea principal. El análisis se detiene al primer movimiento inválido, en vez de inventar el resto.</p><label className="mt-3 block text-sm font-medium">Posición inicial de esta página (FEN opcional)</label><input value={fenInput} onChange={(e) => {setFenInput(e.target.value); setPly(0);}} className="mt-1 w-full rounded-lg border border-black/15 bg-white p-2 font-mono text-xs"/><p className="mt-2 text-xs text-muted">{moveList.length ? `${moveList.length} medias jugadas reconocidas.` : "Aún no se detectaron jugadas válidas en esta página."}</p>{moves.errors[0] && <p className="mt-2 rounded-lg bg-amber-50 p-2 text-xs text-amber-900">{moves.errors[0]}</p>}{pageCount > 0 && !pageText.trim() && <p className="mt-2 rounded-lg bg-amber-50 p-2 text-xs text-amber-900">Esta página parece escaneada. La lectura automática de diagramas requiere OCR/reconocimiento visual y confirmación de la posición; todavía no se activa automáticamente en esta versión.</p>}</div>
      </section>
    </div>
  </div>;
}
