import { useCallback, useMemo, useState } from "react";
import { BookOpen, CheckCircle2, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";
import { PuzzlePlayer } from "@/components/diagrama/PuzzlePlayer";
import { BookStudy } from "@/components/diagrama/BookStudy";
import { PUZZLES } from "@/lib/chess/puzzles";
import { loadProgress, saveProgress, type Progress } from "@/lib/chess/storage";
import type { Puzzle } from "@/lib/chess/types";
import { cn } from "@/lib/cn";

export function Diagrama() {
  const all = useMemo(() => PUZZLES, []);
  const [progress, setProgress] = useState<Progress>(() => loadProgress());
  const [index, setIndex] = useState(0);
  const [view, setView] = useState<"play" | "list" | "study">("play");

  const puzzle: Puzzle = all[index] ?? all[0];
  const solvedCount = all.filter((p) => progress[p.id]?.solved).length;

  const onSolved = useCallback(() => {
    setProgress((prev) => {
      const next = {
        ...prev,
        [puzzle.id]: { solved: true, wrong: prev[puzzle.id]?.wrong ?? 0 },
      };
      saveProgress(next);
      return next;
    });
  }, [puzzle.id]);

  const onWrong = useCallback(() => {
    setProgress((prev) => {
      const next = {
        ...prev,
        [puzzle.id]: {
          solved: prev[puzzle.id]?.solved ?? false,
          wrong: (prev[puzzle.id]?.wrong ?? 0) + 1,
        },
      };
      saveProgress(next);
      return next;
    });
  }, [puzzle.id]);

  const go = (delta: number) => {
    setIndex((i) => (i + delta + all.length) % all.length);
  };

  if (view === "study") {
    return (
      <div className="mx-auto min-h-dvh max-w-6xl">
        <div className="border-b border-black/8 px-3 py-2.5 sm:px-4">
          <button type="button" onClick={() => setView("play")} className="rounded-lg px-3 py-2 text-sm text-muted hover:bg-black/5">← Volver a ejercicios</button>
        </div>
        <BookStudy />
      </div>
    );
  }

  if (view === "list") {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col gap-4 p-4 pb-10">
        <header className="flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setView("play")}
            className="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm text-muted hover:bg-black/5"
          >
            <ChevronLeft className="size-4" />
            Volver
          </button>
          <p className="text-sm text-muted">
            {solvedCount}/{all.length} resueltos
          </p>
        </header>
        <h1 className="font-display text-2xl">Cuaderno</h1>
        <ul className="space-y-2">
          {all.map((p, i) => {
            const done = progress[p.id]?.solved;
            return (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => {
                    setIndex(i);
                    setView("play");
                  }}
                  className={cn(
                    "flex w-full items-start gap-3 rounded-xl border border-black/8 bg-white/70 px-3 py-3 text-left transition hover:border-black/15",
                    done && "border-emerald-500/30 bg-emerald-50/50",
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-medium",
                      done ? "bg-emerald-600 text-white" : "bg-black/5 text-muted",
                    )}
                  >
                    {done ? <CheckCircle2 className="size-4" /> : i + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-lg leading-tight">{p.title}</span>
                    <span className="mt-0.5 block text-sm text-muted">
                      {p.chapter} · {p.brief}
                    </span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    );
  }

  return (
    <div className="mx-auto flex min-h-dvh max-w-5xl flex-col">
      <header className="flex items-center justify-between gap-2 border-b border-black/8 px-3 py-2.5 sm:px-4">
        <div className="flex min-w-0 items-center gap-2">
          <BookOpen className="size-5 shrink-0 text-[var(--color-theme,#234237)]" />
          <div className="min-w-0">
            <p className="truncate font-display text-lg leading-tight">{puzzle.title}</p>
            <p className="truncate text-xs text-muted">
              {puzzle.chapter} · {index + 1}/{all.length}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setView("study")}
            className="rounded-lg px-2.5 py-1.5 text-sm text-muted hover:bg-black/5"
            title="Lector de libros PDF"
          >
            <BookOpen className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => setView("list")}
            className="rounded-lg px-2.5 py-1.5 text-sm text-muted hover:bg-black/5"
            title="Lista de ejercicios"
          >
            <Sparkles className="size-4" />
          </button>
          <button
            type="button"
            onClick={() => go(-1)}
            className="rounded-lg p-1.5 text-muted hover:bg-black/5"
            aria-label="Anterior"
          >
            <ChevronLeft className="size-5" />
          </button>
          <button
            type="button"
            onClick={() => go(1)}
            className="rounded-lg p-1.5 text-muted hover:bg-black/5"
            aria-label="Siguiente"
          >
            <ChevronRight className="size-5" />
          </button>
        </div>
      </header>

      <main className="flex-1 p-3 sm:p-4">
        <PuzzlePlayer
          key={puzzle.id}
          puzzle={puzzle}
          onSolved={onSolved}
          onWrong={onWrong}
        />
      </main>
    </div>
  );
}
