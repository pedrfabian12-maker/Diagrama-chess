import type { Color } from "chess.js";
import { scoreRows } from "@/lib/chess/notation";

export function Score({
  start,
  sans,
  upto,
}: {
  start: Color;
  sans: string[];
  upto?: number;
}) {
  const rows = scoreRows(start, sans.slice(0, upto ?? sans.length));
  if (!rows.length) {
    return <p className="text-sm text-muted">Todavía no hay jugadas.</p>;
  }
  return (
    <ol className="space-y-1 font-display text-lg leading-snug">
      {rows.map((row) => (
        <li key={`${row.num}-${row.blackFirst ? "b" : "w"}`} className="flex gap-3 tabular-nums">
          <span className="w-6 text-muted">{row.num}.</span>
          {row.blackFirst ? (
            <span className="text-muted">… {row.black}</span>
          ) : (
            <>
              <span className="min-w-16">{row.white}</span>
              {row.black ? <span>{row.black}</span> : null}
            </>
          )}
        </li>
      ))}
    </ol>
  );
}
