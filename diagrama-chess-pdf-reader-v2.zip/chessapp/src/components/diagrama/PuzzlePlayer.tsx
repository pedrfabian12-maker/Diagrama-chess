import { useEffect, useState } from "react";
import { Chess, type Square } from "chess.js";
import { Eye, Lightbulb, RotateCcw } from "lucide-react";
import { Board } from "@/components/chess/Board";
import { PieceGlyph } from "@/components/chess/Piece";
import { Score } from "@/components/diagrama/Score";
import { bookMove, fenAt } from "@/lib/chess/position";
import type { Puzzle } from "@/lib/chess/types";
import { cn } from "@/lib/cn";

type Phase = "play" | "replay" | "done";

export function PuzzlePlayer({
  puzzle,
  onSolved,
  onWrong,
}: {
  puzzle: Puzzle;
  onSolved: () => void;
  onWrong: () => void;
}) {
  const [ply, setPly] = useState(0);
  const [phase, setPhase] = useState<Phase>("play");
  const [selected, setSelected] = useState<Square | null>(null);
  const [pending, setPending] = useState<{ from: Square; to: Square } | null>(null);
  const [flash, setFlash] = useState<Square | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [hint, setHint] = useState(0);
  const [showLine, setShowLine] = useState(false);
  const [showSchemes, setShowSchemes] = useState(false);

  const solver = new Chess(puzzle.fen).turn();
  const fen = fenAt(puzzle.fen, puzzle.solution, ply);
  const chess = new Chess(fen);
  const yourTurn = phase === "play" && ply < puzzle.solution.length && chess.turn() === solver;
  const finished = phase === "done";

  useEffect(() => {
    if (ply >= puzzle.solution.length) {
      setPhase("done");
      setSelected(null);
      setPending(null);
      return;
    }
    const turn = new Chess(fenAt(puzzle.fen, puzzle.solution, ply)).turn();
    const auto = phase === "replay" || (phase === "play" && turn !== solver);
    if (!auto) return;
    const delay = phase === "replay" ? 720 : 460;
    const timer = window.setTimeout(() => setPly((p) => p + 1), delay);
    return () => window.clearTimeout(timer);
  }, [phase, ply, puzzle.fen, puzzle.solution, solver]);

  useEffect(() => {
    if (phase === "done") onSolved();
  }, [phase, onSolved]);

  useEffect(() => {
    if (!flash) return;
    const timer = window.setTimeout(() => setFlash(null), 480);
    return () => window.clearTimeout(timer);
  }, [flash]);

  const last =
    ply > 0 ? { from: bookMove(puzzle.fen, puzzle.solution, ply - 1) } : null;
  const lastMove =
    last?.from && "from" in last.from ? { from: last.from.from, to: last.from.to } : null;

  let check: Square | null = null;
  if (chess.inCheck()) {
    for (const row of chess.board()) {
      for (const cell of row) {
        if (cell?.type === "k" && cell.color === chess.turn()) check = cell.square;
      }
    }
  }

  const targets =
    yourTurn && selected
      ? chess.moves({ square: selected, verbose: true }).map((move) => ({
          square: move.to,
          capture: Boolean(move.captured),
          promotion: Boolean(move.promotion),
        }))
      : [];

  const expected = ply < puzzle.solution.length ? bookMove(puzzle.fen, puzzle.solution, ply) : null;
  const marked: Square[] =
    yourTurn && expected ? (hint >= 2 ? [expected.from, expected.to] : hint === 1 ? [expected.from] : []) : [];

  function reject(square: Square) {
    setFlash(square);
    setNote("Esa no es la jugada del libro.");
    setPending(null);
    setSelected(null);
    onWrong();
  }

  function tryMove(from: Square, to: Square, promotion?: "q" | "r" | "b" | "n") {
    if (!expected) return;
    const promo = promotion ?? expected.promotion;
    const needsPromo = targets.find((t) => t.square === to)?.promotion;
    if (needsPromo && !promotion) {
      setPending({ from, to });
      return;
    }
    const same =
      expected.from === from &&
      expected.to === to &&
      (expected.promotion ?? undefined) === (promo ?? undefined);
    if (!same) {
      reject(to);
      return;
    }
    setPly((p) => p + 1);
    setSelected(null);
    setPending(null);
    setHint(0);
    setNote(null);
  }

  function onSquare(square: Square) {
    if (!yourTurn) return;
    if (pending) return;
    const target = targets.find((t) => t.square === square);
    if (selected && target) {
      tryMove(selected, square);
      return;
    }
    const piece = chess.get(square);
    if (piece && piece.color === solver) {
      setSelected(square);
      return;
    }
    setSelected(null);
  }

  function replay() {
    setPly(0);
    setPhase("replay");
    setShowLine(true);
    setNote(null);
    setHint(0);
    setSelected(null);
  }

  function reset() {
    setPly(0);
    setPhase("play");
    setNote(null);
    setHint(0);
    setSelected(null);
    setPending(null);
  }

  const status = finished
    ? chess.isCheckmate()
      ? "Mate. La línea del diagrama está completa."
      : "Línea completa."
    : phase === "replay"
      ? "Reproduciendo la solución."
      : yourTurn
        ? solver === "w"
          ? "Juegan las blancas. Tu jugada."
          : "Juegan las negras. Tu jugada."
        : "Respuesta del libro.";

  const schemesOpen = showSchemes || finished;
  const lineOpen = showLine || finished;

  return (
    <div className="grid items-start gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="min-w-0">
        <Board
          fen={fen}
          interactive={yourTurn}
          selected={selected}
          targets={targets.map(({ square, capture }) => ({ square, capture }))}
          last={lastMove}
          check={check}
          flash={flash}
          marked={marked}
          onSquare={onSquare}
        />
        {pending ? (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted">Coronación</span>
            {(["q", "r", "b", "n"] as const).map((type) => (
              <button
                key={type}
                type="button"
                className="flex size-11 items-center justify-center bg-cream ring-1 ring-line"
                onClick={() => tryMove(pending.from, pending.to, type)}
                aria-label={`Coronar ${type}`}
              >
                <PieceGlyph type={type} color={solver} className="w-4/5" />
              </button>
            ))}
          </div>
        ) : null}
      </div>

      <aside className="border border-line bg-cream p-4 sm:p-5">
        <p className="text-xs tracking-widest text-muted uppercase">{puzzle.chapter}</p>
        <h2 className="mt-1 font-display text-3xl leading-tight">{puzzle.title}</h2>
        <p className="mt-1 text-sm text-muted">{puzzle.cite}</p>
        <p className="mt-4 font-display text-lg italic">{puzzle.brief}</p>
        <p className={cn("mt-3 text-sm", note ? "text-vermilion" : "text-ink")}>{note ?? status}</p>

        <div className="mt-4 border-t border-line pt-4">
          <Score start={solver} sans={puzzle.solution.slice(0, ply)} />
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setHint((h) => Math.min(2, h + 1))}
            disabled={!yourTurn}
            className="inline-flex h-11 items-center gap-2 border border-line bg-paper px-3 text-sm disabled:opacity-40"
          >
            <Lightbulb className="size-4" />
            Pista
          </button>
          <button
            type="button"
            onClick={reset}
            className="inline-flex h-11 items-center gap-2 border border-line bg-paper px-3 text-sm"
          >
            <RotateCcw className="size-4" />
            Reiniciar
          </button>
        </div>

        <section className="mt-6 border-t border-line pt-4">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-display text-xl">Solución</h3>
            {!lineOpen ? (
              <button
                type="button"
                onClick={() => setShowLine(true)}
                className="inline-flex h-11 items-center gap-2 text-sm text-forest"
              >
                <Eye className="size-4" />
                Mostrar
              </button>
            ) : null}
          </div>
          {lineOpen ? (
            <>
              <div className="mt-3">
                <Score start={solver} sans={puzzle.solution} />
              </div>
              <button
                type="button"
                onClick={replay}
                className="mt-3 h-11 bg-forest px-4 text-sm text-cream"
              >
                Reproducir
              </button>
            </>
          ) : (
            <p className="mt-2 text-sm text-muted">La línea sigue oculta mientras resuelves.</p>
          )}
        </section>

        <section className="mt-6 border-t border-line pt-4">
          <div className="flex items-center justify-between gap-3">
            <h3 className="font-display text-xl">Esquemas</h3>
            {!schemesOpen ? (
              <button type="button" onClick={() => setShowSchemes(true)} className="h-11 text-sm text-forest">
                Abrir
              </button>
            ) : null}
          </div>
          {schemesOpen ? (
            <ul className="mt-3 space-y-4">
              {puzzle.schemes.map((scheme) => {
                let schemeFen = puzzle.fen;
                try {
                  schemeFen = fenAt(puzzle.fen, puzzle.solution, Math.min(scheme.afterPly, puzzle.solution.length));
                } catch {
                  schemeFen = puzzle.fen;
                }
                return (
                  <li key={`${scheme.afterPly}-${scheme.title}`}>
                    <div className="max-w-44">
                      <Board fen={schemeFen} coords={false} />
                    </div>
                    <p className="mt-2 font-display text-lg">{scheme.title}</p>
                    <p className="text-sm leading-relaxed text-muted">{scheme.note}</p>
                  </li>
                );
              })}
            </ul>
          ) : (
            <p className="mt-2 text-sm text-muted">Se abren al resolver, o cuando tú quieras.</p>
          )}
        </section>
      </aside>
    </div>
  );
}
