import type { Square } from "chess.js";
import { cn } from "@/lib/cn";
import { FILES, isDark, type SquareMap } from "@/lib/chess/position";
import { fenToSetup } from "@/lib/chess/position";
import { PieceGlyph, pieceLabel } from "@/components/chess/Piece";

const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;

export function Board({
  fen,
  map,
  interactive = false,
  selected = null,
  targets = [],
  last = null,
  check = null,
  flash = null,
  marked = [],
  coords = true,
  onSquare,
}: {
  fen?: string;
  map?: SquareMap;
  interactive?: boolean;
  selected?: Square | null;
  targets?: { square: Square; capture: boolean }[];
  last?: { from: Square; to: Square } | null;
  check?: Square | null;
  flash?: Square | null;
  marked?: Square[];
  coords?: boolean;
  onSquare?: (square: Square) => void;
}) {
  const position = map ?? (fen ? fenToSetup(fen)?.map : undefined) ?? {};
  const targetBySquare = new Map(targets.map((t) => [t.square, t]));

  return (
    <div className="bg-ink p-2 shadow-lg sm:p-3">
      <div className="grid grid-cols-8">
        {RANKS.flatMap((rank) =>
          FILES.map((file) => {
            const square = `${file}${rank}` as Square;
            const piece = position[square];
            const dark = isDark(square);
            const target = targetBySquare.get(square);
            const isLast = last?.from === square || last?.to === square;
            const isSelected = selected === square;
            return (
              <button
                key={square}
                type="button"
                aria-label={piece ? `${pieceLabel(piece.type, piece.color)} en ${square}` : square}
                onClick={() => interactive && onSquare?.(square)}
                tabIndex={interactive ? 0 : -1}
                className={cn(
                  "relative flex aspect-square items-center justify-center",
                  dark ? "bg-forest" : "bg-cream",
                  interactive && "focus-visible:z-10 focus-visible:outline-2 focus-visible:outline-vermilion",
                  !interactive && "cursor-default",
                )}
              >
                {isLast ? (
                  <span
                    className={cn("absolute inset-0", dark ? "bg-cream/25" : "bg-forest/20")}
                  />
                ) : null}
                {isSelected ? <span className="absolute inset-1 ring-2 ring-vermilion ring-inset" /> : null}
                {check === square ? (
                  <span className="absolute inset-0.5 ring-2 ring-vermilion ring-inset" />
                ) : null}
                {marked.includes(square) ? (
                  <span className="absolute inset-1 ring-2 ring-dashed ring-vermilion ring-inset" />
                ) : null}
                {flash === square ? <span className="flash-square absolute inset-0 bg-vermilion/50" /> : null}
                {coords && file === "a" ? (
                  <span
                    className={cn(
                      "absolute top-0.5 left-0.5 text-xs leading-none",
                      dark ? "text-cream/80" : "text-forest",
                    )}
                  >
                    {rank}
                  </span>
                ) : null}
                {coords && rank === "1" ? (
                  <span
                    className={cn(
                      "absolute right-0.5 bottom-0.5 text-xs leading-none",
                      dark ? "text-cream/80" : "text-forest",
                    )}
                  >
                    {file}
                  </span>
                ) : null}
                {target ? (
                  target.capture ? (
                    <span
                      className={cn(
                        "absolute inset-0 rounded-full border-4",
                        dark ? "border-cream/80" : "border-forest/70",
                      )}
                    />
                  ) : (
                    <span
                      className={cn(
                        "absolute size-2 rounded-full sm:size-3",
                        dark ? "bg-cream/85" : "bg-forest/70",
                      )}
                    />
                  )
                ) : null}
                {piece ? (
                  <PieceGlyph
                    type={piece.type}
                    color={piece.color}
                    className={cn("relative z-10 w-4/5", isSelected && "-translate-y-0.5")}
                  />
                ) : null}
              </button>
            );
          }),
        )}
      </div>
    </div>
  );
}
