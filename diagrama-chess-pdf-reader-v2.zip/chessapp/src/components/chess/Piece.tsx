import type { ReactNode } from "react";
import type { Color, PieceSymbol } from "chess.js";

type Ink = { fill: string; stroke: string };

function Pawn({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <circle cx="22.5" cy="14" r="5.2" />
      <path d="M16.2 27.2c1.1-3 3.2-4.6 6.3-4.6s5.2 1.6 6.3 4.6c1.8.5 3.2 2 3.2 3.8v1.2H13v-1.2c0-1.8 1.4-3.3 3.2-3.8z" />
      <path d="M12.2 33.6h20.6v3.6H12.2z" />
    </g>
  );
}

function Rook({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <path d="M11 12h6.2v4.2h4.2V12h5.2v4.2H31V12h6v8.2H11z" />
      <path d="M15.2 20.2h14.6l-1.4 9.2H16.6z" />
      <path d="M12 31h21v4.2H12z" />
    </g>
  );
}

function Knight({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <path d="M35.2 35.6h-6.2c-.2-2.4-.8-3.6-2.2-4.2 1.6-1 2.8-2.6 3-4.6l3.4 1.2.8-3.2-4.2-2.2c.6-1.6.4-3.4-.8-4.8l1.4-3.4-3.6-1.2-1.6 2.6c-.8-.4-1.8-.6-2.8-.4-3.2.4-5.4 2.6-6.4 5.6l-3.8 1.2c-.6.2-.8 1-.4 1.6l2.2 3.2c-1.6 1.4-2.4 3.4-2 5.4l-2.6 1.2-.4 3.2H9.2v3.4h26z" />
      <circle cx="22.2" cy="16.6" r="1.05" fill={stroke} stroke="none" />
    </g>
  );
}

function Bishop({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <circle cx="22.5" cy="10.2" r="2.3" />
      <path d="M22.5 14.2c-4.8 1.6-8 6.4-8 11.2 0 2.2.6 3.6 1.6 4.6h12.8c1-1 1.6-2.4 1.6-4.6 0-4.8-3.2-9.6-8-11.2z" />
      <path d="M16.4 31.2h12.2l1.2 2.2H15.2z" />
      <path d="M12.4 34.6h20.2v3.4H12.4z" />
      <path d="M22.5 16.8v8.2" fill="none" stroke={stroke} strokeWidth="1.4" />
    </g>
  );
}

function Queen({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <circle cx="9.5" cy="13" r="2.15" />
      <circle cx="16.2" cy="9.2" r="2.15" />
      <circle cx="22.5" cy="7.6" r="2.35" />
      <circle cx="28.8" cy="9.2" r="2.15" />
      <circle cx="35.5" cy="13" r="2.15" />
      <path d="M10.4 16.2 14.2 28h16.6l3.8-11.8-5.2 4.2L22.5 14.8 15.6 20.4z" />
      <path d="M14.6 29.4h15.8l1.1 2H13.5z" />
      <path d="M12 33.2h21v3.6H12z" />
    </g>
  );
}

function King({ fill, stroke }: Ink) {
  return (
    <g fill={fill} stroke={stroke} strokeWidth="1.35" strokeLinejoin="round">
      <path d="M21 6.2h3v3.2h3.2v3H24v3.2h-3v-3.2h-3.2v-3H21z" />
      <path d="M13.2 18.2h18.6l-2.2 10.2H15.4z" />
      <path d="M15.2 29.6h14.6l1.2 2.2H14z" />
      <path d="M12 33.6h21v3.6H12z" />
    </g>
  );
}

const GLYPHS = {
  p: Pawn,
  r: Rook,
  n: Knight,
  b: Bishop,
  q: Queen,
  k: King,
} satisfies Record<PieceSymbol, (ink: Ink) => ReactNode>;

export function PieceGlyph({
  type,
  color,
  className,
}: {
  type: PieceSymbol;
  color: Color;
  className?: string;
}) {
  const Glyph = GLYPHS[type];
  const fill = color === "w" ? "var(--color-cream)" : "var(--color-ink)";
  const stroke = color === "w" ? "var(--color-ink)" : "var(--color-cream)";
  return (
    <svg viewBox="0 0 45 45" className={className} aria-hidden>
      <Glyph fill={fill} stroke={stroke} />
    </svg>
  );
}

const NAMES: Record<PieceSymbol, string> = {
  k: "rey",
  q: "dama",
  r: "torre",
  b: "alfil",
  n: "caballo",
  p: "peón",
};

export function pieceLabel(type: PieceSymbol, color: Color): string {
  return `${NAMES[type]} ${color === "w" ? "blanco" : "negro"}`;
}
