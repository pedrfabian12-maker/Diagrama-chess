# Diagrama → APK para Android

El proyecto ya está preparado con **Capacitor 8** y la plataforma Android.

## Resumen rápido

| Qué | Valor |
|-----|--------|
| App ID | `app.diagrama.chess` |
| Nombre | Diagrama |
| Carpeta nativa | `android/` |
| Assets web | `www/` |
| Color tema | `#234237` |

## Requisitos en tu máquina

- [Node.js 20+](https://nodejs.org/)
- [Android Studio](https://developer.android.com/studio) (incluye SDK, emulador y Gradle)
- JDK 17 o 21 (Android Studio lo trae)

## Opción recomendada: APK que carga tu web desplegada

Esta app es SSR (TanStack Start + Nitro). La forma más fiable y rápida de tener un APK funcional es que el WebView cargue tu despliegue (Vercel u otro).

### 1. Despliega la web

```bash
npm run build
# sube a Vercel / Netlify / el host que uses
```

Anota la URL, por ejemplo: `https://diagrama.vercel.app`

### 2. Configura Capacitor

Edita `capacitor.config.ts` y descomenta / rellena:

```ts
server: {
  url: "https://TU-URL.vercel.app",
  cleartext: false,
},
```

### 3. Sincroniza y abre Android Studio

```bash
npm run build:capacitor   # opcional, actualiza www/
npx cap sync android
npx cap open android
```

### 4. Genera el APK / AAB

En Android Studio:

1. **Build → Generate Signed Bundle / APK**
2. Elige **APK** (pruebas) o **Android App Bundle** (Play Store)
3. Crea o elige un keystore
4. Build variant: **release**

El APK quedará en algo como:

```
android/app/release/app-release.apk
```

## Scripts útiles

```bash
npm run build:capacitor   # build web + copia assets a www/
npm run cap:sync          # npx cap sync android
npm run cap:open          # abre Android Studio
npm run cap:add:android   # (ya hecho) añade la plataforma
```

## Desarrollo con live reload

Mientras desarrollas, puedes apuntar el APK al servidor de desarrollo de tu PC:

```ts
// capacitor.config.ts (solo en local)
server: {
  url: "http://192.168.x.x:8080",  // IP de tu máquina en la LAN
  cleartext: true,
},
```

Luego:

```bash
npm run dev
npx cap sync android
npx cap open android
```

El emulador/dispositivo debe estar en la misma red Wi‑Fi.

## Iconos y splash

- Iconos por defecto de Capacitor están en `android/app/src/main/res/mipmap-*`
- Splash: `android/app/src/main/res/drawable/splash.png`
- Color de fondo del launcher: `#234237`

Para iconos personalizados puedes usar [capacitor-assets](https://github.com/ionic-team/capacitor-assets) o Android Studio → Image Asset.

## Play Store

1. Genera un **AAB** (Android App Bundle), no solo APK
2. Crea la app en [Google Play Console](https://play.google.com/console)
3. Sube el AAB en producción o prueba interna
4. Completa ficha, capturas y política de privacidad

## Notas técnicas

- La carpeta `android/` está lista; no hace falta volver a ejecutar `cap add android` salvo que la borres.
- Tras cambiar `capacitor.config.ts` o el contenido de `www/`, siempre ejecuta `npx cap sync android`.
- Permiso de Internet ya está declarado (necesario para cargar la web remota).
- El progreso de los ejercicios se guarda en `localStorage` del WebView (persiste entre sesiones en el mismo dispositivo).

## Solución de problemas

| Problema | Qué hacer |
|----------|-----------|
| Pantalla en blanco | Revisa `server.url` y que la web responda por HTTPS |
| `cleartext` / HTTP bloqueado | Solo en debug; usa `cleartext: true` y HTTP en la misma LAN |
| Gradle sync falla | Abre Android Studio → File → Sync Project with Gradle Files; acepta licenses del SDK |
| Icono genérico | Sustituye los mipmap o usa Image Asset Studio |

Si quieres un APK 100 % offline (sin servidor), hace falta un modo SPA / prerender del cliente. Se puede hacer en un siguiente paso.
